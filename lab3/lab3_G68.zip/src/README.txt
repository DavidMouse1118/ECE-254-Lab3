The source code of multi-thread implemention:
	thead.c

The source code of multi-process implemention:
	producer.c
	consumer.c
	process.c


To compile the multi-thread implementaion
    $ make thread

To compile the multi-process implementaion
    $ make process

To run the .out file 
    $ ./produce <N> <B> <P> <C>


